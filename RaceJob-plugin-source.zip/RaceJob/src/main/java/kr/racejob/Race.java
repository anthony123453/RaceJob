package kr.racejob;

import org.bukkit.Material;

public enum Race {
    HUMAN("사람", Material.PLAYER_HEAD, "능력 없음"),
    MERMAN("어인", Material.COD,
            "물속: 채굴속도 증가, 산소 무한, 힘 II, 저항, 수영속도 +50%",
            "단점: 지상에서는 물고기(체력/속도 물고기 수준)"),
    BIRD("새", Material.FEATHER,
            "겉날개 지급 (귀속 저주)",
            "단점: 최대 체력 절반"),
    FURRY("퍼리", Material.BONE,
            "이동속도, 점프력 +20%",
            "단점: 채팅 뒤에 meow 가 붙음"),
    VAMPIRE("흡혈귀", Material.REDSTONE,
            "플레이어 타격 시 체력 0.5칸 회복, 밤에 이동속도 +30%",
            "단점: 낮에 불탐(화염저항 무효), 익힌 고기 못 먹음, 불 피해 증가"),
    BLIND("장님", Material.BLACK_DYE,
            "공격력 2배, 받는 피해 절반",
            "단점: 실명 효과"),
    GIANT("거인", Material.IRON_BLOCK,
            "공격력 2배, 받는 피해 절반, 이동속도 x1.5, 신체 크기 2배"),
    DWARF("소인", Material.LEATHER_BOOTS,
            "이동속도 x1.5",
            "단점: 공격력 절반, 낙하 피해 2배");

    public final String display;
    public final Material icon;
    public final String[] lore;

    Race(String display, Material icon, String... lore) {
        this.display = display;
        this.icon = icon;
        this.lore = lore;
    }
}
