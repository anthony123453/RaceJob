package kr.racejob;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class RaceJobPlugin extends JavaPlugin {

    public static final double[] SWORD_BONUS = {0.20, 0.25, 0.30, 0.40};
    public static final double[] BOW_BONUS = {0.20, 0.25, 0.30, 0.40};
    public static final double[] BRAWL_BONUS = {0.20, 0.40, 0.60, 1.00};
    public static final int[] MUSIC_INTERVAL = {5, 3, 2, 1};

    public NamespacedKey kRace, kJob, kTier, kPendRace, kPendJob, kInit, kTag, kChoice;

    public final Map<UUID, Race> raceCache = new ConcurrentHashMap<>();
    public final Map<UUID, String> stateCache = new HashMap<>();
    public final Set<UUID> disguised = new HashSet<>();
    public final Map<UUID, Integer> musicCount = new HashMap<>();
    public final Map<UUID, Long> buffUntil = new HashMap<>();
    public final Map<UUID, Long> buffReady = new HashMap<>();
    public final Set<UUID> echoing = new HashSet<>();

    private String modNamespace;

    /** 종족/직업 선택 메뉴 식별용 */
    public static class MenuHolder implements InventoryHolder {
        public final boolean race;
        public Inventory inv;
        public MenuHolder(boolean race) { this.race = race; }
        @Override public Inventory getInventory() { return inv; }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        kRace = new NamespacedKey(this, "race");
        kJob = new NamespacedKey(this, "job");
        kTier = new NamespacedKey(this, "tier");
        kPendRace = new NamespacedKey(this, "pend_race");
        kPendJob = new NamespacedKey(this, "pend_job");
        kInit = new NamespacedKey(this, "init");
        kTag = new NamespacedKey(this, "tag");
        kChoice = new NamespacedKey(this, "choice");
        modNamespace = kRace.getNamespace();

        CraftListener craft = new CraftListener(this);
        getServer().getPluginManager().registerEvents(new GameListener(this), this);
        getServer().getPluginManager().registerEvents(craft, this);
        craft.setupRecipes();

        Bukkit.getScheduler().runTaskTimer(this, this::tickFast, 20L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickSecond, 20L, 20L);

        for (Player p : Bukkit.getOnlinePlayers()) {
            raceCache.remove(p.getUniqueId());
            refresh(p);
        }
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            clearMods(p);
            syncDisguise(p, false);
        }
    }

    // ───────────────────────── 데이터 ─────────────────────────

    public Race getRace(Player p) {
        Race c = raceCache.get(p.getUniqueId());
        if (c != null) return c;
        String s = p.getPersistentDataContainer().get(kRace, PersistentDataType.STRING);
        Race r = Race.HUMAN;
        if (s != null) {
            try { r = Race.valueOf(s); } catch (IllegalArgumentException ignored) { }
        }
        raceCache.put(p.getUniqueId(), r);
        return r;
    }

    public void setRace(Player p, Race r) {
        p.getPersistentDataContainer().set(kRace, PersistentDataType.STRING, r.name());
        raceCache.put(p.getUniqueId(), r);
    }

    public Job getJob(Player p) {
        String s = p.getPersistentDataContainer().get(kJob, PersistentDataType.STRING);
        if (s == null) return null;
        try { return Job.valueOf(s); } catch (IllegalArgumentException e) { return null; }
    }

    public void setJob(Player p, Job j) {
        if (j == null) p.getPersistentDataContainer().remove(kJob);
        else p.getPersistentDataContainer().set(kJob, PersistentDataType.STRING, j.name());
    }

    public int getTier(Player p) {
        Integer i = p.getPersistentDataContainer().get(kTier, PersistentDataType.INTEGER);
        return i == null ? 0 : Math.max(0, Math.min(3, i));
    }

    public void setTier(Player p, int t) {
        p.getPersistentDataContainer().set(kTier, PersistentDataType.INTEGER, Math.max(0, Math.min(3, t)));
    }

    public boolean flag(Player p, NamespacedKey k) {
        Byte b = p.getPersistentDataContainer().get(k, PersistentDataType.BYTE);
        return b != null && b == 1;
    }

    public void setFlag(Player p, NamespacedKey k, boolean v) {
        p.getPersistentDataContainer().set(k, PersistentDataType.BYTE, (byte) (v ? 1 : 0));
    }

    public boolean extraUnlocked(Player p) {
        return getTier(p) >= getConfig().getInt("extra-ability-tier", 3);
    }

    // ───────────────────────── 아이템 ─────────────────────────

    public ItemStack makeItem(Material m, String name, String tag, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) meta.setLore(Arrays.asList(lore));
        if (tag != null) meta.getPersistentDataContainer().set(kTag, PersistentDataType.STRING, tag);
        it.setItemMeta(meta);
        return it;
    }

    public String tagOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(kTag, PersistentDataType.STRING);
    }

    public ItemStack starItem() {
        ItemStack it = makeItem(Material.NETHER_STAR, "§e전직의 별", "star",
                "§7우클릭하면 직업이 한 단계 성장합니다", "§7(T1 → T2 → T3)");
        ItemMeta m = it.getItemMeta();
        m.setEnchantmentGlintOverride(true);
        it.setItemMeta(m);
        return it;
    }

    public ItemStack ticketItem(boolean race) {
        return race
                ? makeItem(Material.PAPER, "§a종족 선택권", "ticket_race", "§7우클릭하여 종족을 다시 선택합니다")
                : makeItem(Material.PAPER, "§b직업 선택권", "ticket_job", "§7우클릭하여 직업을 다시 선택합니다");
    }

    public void giveOrDrop(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        for (ItemStack l : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), l);
    }

    public void removeTagged(Player p, String tag) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] c = inv.getContents();
        for (int i = 0; i < c.length; i++) {
            if (tag.equals(tagOf(c[i]))) inv.setItem(i, null);
        }
    }

    public boolean hasTagged(Player p, String tag) {
        for (ItemStack i : p.getInventory().getContents()) {
            if (tag.equals(tagOf(i))) return true;
        }
        return false;
    }

    private ItemStack cursed(ItemStack it) {
        ItemMeta m = it.getItemMeta();
        m.addEnchant(Enchantment.BINDING_CURSE, 1, true);
        it.setItemMeta(m);
        return it;
    }

    private void giveRaceItems(Player p, Race r) {
        if (r == Race.BIRD && !hasTagged(p, "race_elytra")) {
            ItemStack e = cursed(makeItem(Material.ELYTRA, "§b새의 날개", "race_elytra"));
            if (p.getInventory().getChestplate() == null) p.getInventory().setChestplate(e);
            else giveOrDrop(p, e);
        }
    }

    private void giveMusicHelmet(Player p) {
        if (hasTagged(p, "music_helmet")) return;
        ItemStack h = cursed(makeItem(Material.JUKEBOX, "§d음악가의 주크박스", "music_helmet"));
        ItemStack old = p.getInventory().getHelmet();
        if (old != null && old.getType() != Material.AIR) giveOrDrop(p, old);
        p.getInventory().setHelmet(h);
    }

    /** 리스폰 후 종족/직업 전용 아이템 보충 */
    public void ensureItems(Player p) {
        giveRaceItems(p, getRace(p));
        if (getJob(p) == Job.MUSICIAN) giveMusicHelmet(p);
    }

    // ───────────────────────── 선택 ─────────────────────────

    public void chooseRace(Player p, Race r) {
        Race old = getRace(p);
        removeTagged(p, "race_elytra");
        if (old == Race.MERMAN) {
            p.removePotionEffect(PotionEffectType.WATER_BREATHING);
            p.removePotionEffect(PotionEffectType.STRENGTH);
            p.removePotionEffect(PotionEffectType.RESISTANCE);
        }
        if (old == Race.BLIND) p.removePotionEffect(PotionEffectType.BLINDNESS);
        setRace(p, r);
        setFlag(p, kPendRace, false);
        giveRaceItems(p, r);
        stateCache.remove(p.getUniqueId());
        refresh(p);
        p.sendMessage("§a종족 §f" + r.display + "§a을(를) 선택했습니다!");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }

    /** j == null 이면 직업 제거 */
    public void chooseJob(Player p, Job j) {
        removeTagged(p, "music_helmet");
        setJob(p, j);
        setTier(p, 0);
        setFlag(p, kPendJob, false);
        musicCount.remove(p.getUniqueId());
        if (j == null) {
            p.sendMessage("§e직업이 제거되었습니다.");
            return;
        }
        switch (j) {
            case SWORDSMAN -> giveOrDrop(p, new ItemStack(Material.STONE_SWORD));
            case ARCHER -> {
                giveOrDrop(p, new ItemStack(Material.BOW));
                int n = getConfig().getInt("archer-starter-arrows", 32);
                if (n > 0) giveOrDrop(p, new ItemStack(Material.ARROW, n));
            }
            case MUSICIAN -> giveMusicHelmet(p);
            default -> { }
        }
        p.sendMessage("§a직업 §f" + j.display + "§a을(를) 선택했습니다!");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.3f);
    }

    private ItemStack choiceItem(Material m, String name, String choice, String[] lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add("§7" + s);
        meta.setLore(l);
        meta.getPersistentDataContainer().set(kChoice, PersistentDataType.STRING, choice);
        it.setItemMeta(meta);
        return it;
    }

    public void openRaceMenu(Player p) {
        MenuHolder h = new MenuHolder(true);
        Inventory inv = Bukkit.createInventory(h, 9, "§8종족을 선택하세요");
        h.inv = inv;
        int i = 0;
        for (Race r : Race.values()) inv.setItem(i++, choiceItem(r.icon, "§a" + r.display, r.name(), r.lore));
        p.openInventory(inv);
    }

    public void openJobMenu(Player p) {
        MenuHolder h = new MenuHolder(false);
        Inventory inv = Bukkit.createInventory(h, 9, "§8직업을 선택하세요");
        h.inv = inv;
        int[] slots = {1, 3, 5, 7};
        int i = 0;
        for (Job j : Job.values()) inv.setItem(slots[i++], choiceItem(j.icon, "§b" + j.display, j.name(), j.lore));
        p.openInventory(inv);
    }

    // ───────────────────────── 능력치 갱신 ─────────────────────────

    private void clearMods(Player p) {
        for (Attribute a : Registry.ATTRIBUTE) {
            AttributeInstance ai = p.getAttribute(a);
            if (ai == null) continue;
            for (AttributeModifier m : new ArrayList<>(ai.getModifiers())) {
                if (m.getKey().getNamespace().equals(modNamespace)) ai.removeModifier(m);
            }
        }
    }

    private void mod(Player p, Attribute a, String id, double v, AttributeModifier.Operation op) {
        AttributeInstance ai = p.getAttribute(a);
        if (ai == null) return;
        ai.addModifier(new AttributeModifier(new NamespacedKey(this, id), v, op));
    }

    private boolean isNight(World w) {
        if (w.getEnvironment() != World.Environment.NORMAL) return false;
        long t = w.getTime();
        return t >= 13000 && t <= 23000;
    }

    private boolean isDay(World w) {
        return w.getEnvironment() == World.Environment.NORMAL && w.getTime() < 12000;
    }

    public void refresh(Player p) {
        Race r = getRace(p);
        World w = p.getWorld();
        boolean water = p.isInWater();
        AttributeInstance hp = p.getAttribute(Attribute.MAX_HEALTH);
        double oldMax = hp.getValue();
        double ratio = oldMax > 0 ? p.getHealth() / oldMax : 1.0;

        clearMods(p);
        AttributeModifier.Operation SCALAR = AttributeModifier.Operation.ADD_SCALAR;
        AttributeModifier.Operation NUMBER = AttributeModifier.Operation.ADD_NUMBER;

        switch (r) {
            case BIRD -> mod(p, Attribute.MAX_HEALTH, "bird_hp", -0.5, SCALAR);
            case FURRY -> {
                mod(p, Attribute.MOVEMENT_SPEED, "furry_spd", 0.2, SCALAR);
                mod(p, Attribute.JUMP_STRENGTH, "furry_jump", 0.2, SCALAR);
            }
            case VAMPIRE -> {
                if (isNight(w)) mod(p, Attribute.MOVEMENT_SPEED, "vamp_spd", 0.3, SCALAR);
            }
            case GIANT -> {
                mod(p, Attribute.SCALE, "giant_scale", 1.0, SCALAR);
                mod(p, Attribute.MOVEMENT_SPEED, "giant_spd", 0.5, SCALAR);
            }
            case DWARF -> mod(p, Attribute.MOVEMENT_SPEED, "dwarf_spd", 0.5, SCALAR);
            case MERMAN -> {
                if (water) {
                    mod(p, Attribute.SUBMERGED_MINING_SPEED, "mer_mine", 2.0, SCALAR);
                    mod(p, Attribute.WATER_MOVEMENT_EFFICIENCY, "mer_swim", 0.5, NUMBER);
                } else {
                    // 지상: 대구(체력 3, 속도 매우 느림)
                    mod(p, Attribute.MAX_HEALTH, "fish_hp", 3.0 - hp.getBaseValue(), NUMBER);
                    mod(p, Attribute.MOVEMENT_SPEED, "fish_spd", -0.6, SCALAR);
                }
            }
            default -> { }
        }

        syncDisguise(p, r == Race.MERMAN && !water);

        if (!p.isDead()) {
            double newMax = hp.getValue();
            if (Math.abs(newMax - oldMax) > 0.001) {
                p.setHealth(Math.max(0.1, Math.min(newMax, ratio * newMax)));
            } else if (p.getHealth() > newMax) {
                p.setHealth(newMax);
            }
        }
    }

    private void syncDisguise(Player p, boolean fish) {
        if (!getConfig().getBoolean("use-libsdisguises", true)) return;
        if (!Bukkit.getPluginManager().isPluginEnabled("LibsDisguises")) return;
        UUID id = p.getUniqueId();
        if (fish && disguised.add(id)) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "disguiseplayer " + p.getName() + " cod");
        } else if (!fish && disguised.remove(id)) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "undisguiseplayer " + p.getName());
        }
    }

    private void eff(Player p, PotionEffectType t, int amp, int dur) {
        p.addPotionEffect(new PotionEffect(t, dur, amp, true, false, false));
    }

    // ───────────────────────── 주기 작업 ─────────────────────────

    private void tickFast() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead()) continue;
            Race r = getRace(p);
            World w = p.getWorld();
            boolean water = p.isInWater();
            String state = r.name()
                    + (r == Race.MERMAN && water ? "W" : "")
                    + (r == Race.VAMPIRE && isNight(w) ? "N" : "");
            if (!state.equals(stateCache.get(p.getUniqueId()))) {
                stateCache.put(p.getUniqueId(), state);
                refresh(p);
            }

            switch (r) {
                case MERMAN -> {
                    if (water) {
                        eff(p, PotionEffectType.WATER_BREATHING, 0, 80);
                        eff(p, PotionEffectType.STRENGTH, 1, 80);
                        eff(p, PotionEffectType.RESISTANCE, 0, 80);
                    }
                }
                case BLIND -> eff(p, PotionEffectType.BLINDNESS, 0, 80);
                case VAMPIRE -> {
                    p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
                    if (getConfig().getBoolean("vampire-sun-burn", true)
                            && isDay(w) && !water && !w.hasStorm()
                            && p.getEyeLocation().getBlock().getLightFromSky() >= 15) {
                        p.setFireTicks(Math.max(p.getFireTicks(), 60));
                    }
                }
                default -> { }
            }
        }
    }

    private void tickSecond() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead() || getJob(p) != Job.MUSICIAN) continue;
            int interval = MUSIC_INTERVAL[getTier(p)];
            int c = musicCount.merge(p.getUniqueId(), 1, Integer::sum);
            if (c >= interval) {
                musicCount.put(p.getUniqueId(), 0);
                wave(p);
            }
        }
    }

    private void wave(Player p) {
        Location loc = p.getLocation().add(0, 1, 0);
        World w = p.getWorld();
        w.playSound(loc, Sound.BLOCK_NOTE_BLOCK_CHIME, 1.2f, 0.7f + ThreadLocalRandom.current().nextFloat() * 0.8f);
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8;
            w.spawnParticle(Particle.NOTE, loc.clone().add(Math.cos(a) * 3, 0, Math.sin(a) * 3), 1, 0, 0, 0, 1.0);
        }
        boolean mobs = getConfig().getBoolean("musician-affects-mobs", true);
        for (Entity en : p.getNearbyEntities(3, 3, 3)) {
            if (!(en instanceof LivingEntity v) || en instanceof ArmorStand) continue;
            if (v.getLocation().distanceSquared(p.getLocation()) > 9) continue;
            if (v instanceof Tameable t && t.isTamed()) continue;
            if (v instanceof Player vp) {
                if (vp.getGameMode() == GameMode.CREATIVE || vp.getGameMode() == GameMode.SPECTATOR) continue;
            } else if (!mobs) continue;
            trueDamage(p, v, 1.0);
        }
    }

    /** 갑옷 무시 고정 피해 */
    private void trueDamage(Player src, LivingEntity v, double dmg) {
        double hp = v.getHealth();
        if (hp - dmg <= 0) {
            v.damage(10000, src);
        } else {
            v.setHealth(hp - dmg);
            v.playHurtAnimation(0f);
        }
    }

    public void musicianBuff(Player p) {
        long now = System.currentTimeMillis();
        UUID id = p.getUniqueId();
        Long ready = buffReady.get(id);
        if (ready != null && ready > now) {
            p.sendMessage("§c아직 사용할 수 없습니다. (" + ((ready - now) / 1000 + 1) + "초)");
            return;
        }
        buffUntil.put(id, now + 5000L);
        buffReady.put(id, now + getConfig().getInt("musician-buff-cooldown-seconds", 15) * 1000L);
        p.sendMessage("§d연주 버프! §f5초간 공격력 +20%");
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1.5f);
    }

    /** 같은 피해를 일정 틱 뒤에 다시 입힘 (검사/싸움꾼 추가능력) */
    public void echo(Player atk, LivingEntity victim, double dmg, long... delays) {
        for (long d : delays) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!victim.isValid() || victim.isDead() || !atk.isOnline()) return;
                echoing.add(atk.getUniqueId());
                try {
                    victim.setNoDamageTicks(0);
                    victim.damage(dmg, atk);
                } finally {
                    echoing.remove(atk.getUniqueId());
                }
            }, d);
        }
    }

    // ───────────────────────── 명령어 ─────────────────────────

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String n = c.getName().toLowerCase();
        if (n.equals("race") || n.equals("job")) {
            if (!(s instanceof Player p)) {
                s.sendMessage("플레이어만 사용할 수 있습니다.");
                return true;
            }
            boolean race = n.equals("race");
            if (flag(p, race ? kPendRace : kPendJob)) {
                if (race) openRaceMenu(p); else openJobMenu(p);
            } else if (race) {
                p.sendMessage("§e현재 종족: §f" + getRace(p).display + " §7(종족 선택권 = 종이 + 네더라이트 주괴 조합)");
            } else {
                Job j = getJob(p);
                p.sendMessage("§e현재 직업: §f" + (j == null ? "없음" : j.display + " T" + getTier(p))
                        + " §7(직업 선택권 = 종이 + 네더의 별 조합)");
            }
            return true;
        }

        // /rj
        if (!s.hasPermission("racejob.admin")) {
            s.sendMessage("§c권한이 없습니다.");
            return true;
        }
        String usage = "§e/rj race <플레이어> <" + Arrays.toString(Race.values()).toLowerCase() + ">\n"
                + "§e/rj job <플레이어> <" + Arrays.toString(Job.values()).toLowerCase() + "|none>\n"
                + "§e/rj tier <플레이어> <0-3>\n§e/rj give <플레이어> <race|job|star> [개수]\n§e/rj reload";
        if (a.length == 0) { s.sendMessage(usage); return true; }
        if (a[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            s.sendMessage("§a설정을 다시 불러왔습니다.");
            return true;
        }
        if (a.length < 3) { s.sendMessage(usage); return true; }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) { s.sendMessage("§c플레이어를 찾을 수 없습니다."); return true; }
        try {
            switch (a[0].toLowerCase()) {
                case "race" -> chooseRace(t, Race.valueOf(a[2].toUpperCase()));
                case "job" -> chooseJob(t, a[2].equalsIgnoreCase("none") ? null : Job.valueOf(a[2].toUpperCase()));
                case "tier" -> setTier(t, Integer.parseInt(a[2]));
                case "give" -> {
                    int cnt = a.length > 3 ? Integer.parseInt(a[3]) : 1;
                    ItemStack it = switch (a[2].toLowerCase()) {
                        case "race" -> ticketItem(true);
                        case "job" -> ticketItem(false);
                        default -> starItem();
                    };
                    it.setAmount(Math.max(1, Math.min(64, cnt)));
                    giveOrDrop(t, it);
                }
                default -> { s.sendMessage(usage); return true; }
            }
            s.sendMessage("§a완료.");
        } catch (IllegalArgumentException ex) {
            s.sendMessage("§c잘못된 값입니다.\n" + usage);
        }
        return true;
    }
}
