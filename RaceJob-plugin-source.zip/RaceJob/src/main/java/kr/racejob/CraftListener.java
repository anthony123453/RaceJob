package kr.racejob;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.SmithItemEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * - 구리/철/금/다이아 도구의 기존 제작법 삭제 → 모루에서 확률 제작
 * - 네더라이트 도구: 스미딩 테이블 업그레이드 시 확률, 실패 시 파괴
 * - 전직의 별 / 선택권 제작법 등록
 */
public class CraftListener implements Listener {

    private final RaceJobPlugin plugin;

    record Tool(Material result, Material ingot, int ingots, int sticks, String tierKey, boolean axe) { }

    private final List<Tool> tools = new ArrayList<>();

    public CraftListener(RaceJobPlugin plugin) {
        this.plugin = plugin;
        String[][] tiers = {
                {"COPPER", "COPPER_INGOT", "copper"},
                {"IRON", "IRON_INGOT", "iron"},
                {"GOLDEN", "GOLD_INGOT", "gold"},
                {"DIAMOND", "DIAMOND", "diamond"}};
        // 종류, 재료 개수, 막대기 개수, 도끼 여부(이름표로 구분)
        Object[][] kinds = {
                {"SWORD", 2, 1, false},
                {"SHOVEL", 1, 2, false},
                {"HOE", 2, 2, false},
                {"PICKAXE", 3, 2, false},
                {"AXE", 3, 2, true}};
        for (String[] t : tiers) {
            Material ingot = Material.matchMaterial(t[1]);
            if (ingot == null) continue;
            for (Object[] k : kinds) {
                Material res = Material.matchMaterial(t[0] + "_" + k[0]); // 서버에 없는 도구(구리 등)는 자동 제외
                if (res == null) continue;
                tools.add(new Tool(res, ingot, (int) k[1], (int) k[2], t[2], (boolean) k[3]));
            }
        }
    }

    public void setupRecipes() {
        // 1) 기존 제작법 삭제
        Set<Material> targets = new HashSet<>();
        for (Tool t : tools) targets.add(t.result());
        List<NamespacedKey> remove = new ArrayList<>();
        Iterator<Recipe> it = Bukkit.recipeIterator();
        while (it.hasNext()) {
            Recipe r = it.next();
            if (r instanceof Keyed k && (r instanceof ShapedRecipe || r instanceof ShapelessRecipe)
                    && targets.contains(r.getResult().getType())) {
                remove.add(k.getKey());
            }
        }
        for (NamespacedKey k : remove) Bukkit.removeRecipe(k);

        // 2) 전직의 별 / 선택권
        addShapeless("career_star", plugin.starItem(),
                Material.EMERALD_BLOCK, Material.DIAMOND_BLOCK, Material.REDSTONE_BLOCK, Material.GOLD_BLOCK,
                Material.IRON_BLOCK, Material.COPPER_BLOCK, Material.PAPER, Material.COBBLESTONE);
        addShapeless("ticket_race", plugin.ticketItem(true), Material.PAPER, Material.NETHERITE_INGOT);
        addShapeless("ticket_job", plugin.ticketItem(false), Material.PAPER, Material.NETHER_STAR);

        Bukkit.updateRecipes();
    }

    private void addShapeless(String key, ItemStack result, Material... mats) {
        NamespacedKey k = new NamespacedKey(plugin, key);
        Bukkit.removeRecipe(k);
        ShapelessRecipe r = new ShapelessRecipe(k, result);
        for (Material m : mats) r.addIngredient(m);
        Bukkit.addRecipe(r);
    }

    /** 커스텀 아이템(선택권/별 등)을 일반 제작 재료로 쓰는 것 방지 */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        for (ItemStack i : e.getInventory().getMatrix()) {
            if (plugin.tagOf(i) != null) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    // ───────────────────────── 모루 제작 ─────────────────────────

    private Tool match(Inventory inv, String rename) {
        ItemStack a = inv.getItem(0);
        ItemStack b = inv.getItem(1);
        if (a == null || b == null || b.getType() != Material.STICK) return null;
        String rn = rename == null ? "" : rename.trim();
        boolean axeName = rn.equalsIgnoreCase("axe") || rn.equals("도끼");
        for (Tool t : tools) {
            if (t.ingot() == a.getType() && t.ingots() == a.getAmount()
                    && t.sticks() == b.getAmount() && t.axe() == axeName) {
                return t;
            }
        }
        return null;
    }

    private double chance(String key) {
        return plugin.getConfig().getDouble("chances." + key, 0.5);
    }

    @EventHandler
    public void onPrepareAnvil(PrepareAnvilEvent e) {
        AnvilView v = e.getView();
        Tool t = match(e.getInventory(), v.getRenameText());
        if (t == null) return;
        ItemStack res = new ItemStack(t.result());
        ItemMeta m = res.getItemMeta();
        m.setLore(List.of("§7제작 성공 확률: §e" + (int) Math.round(chance(t.tierKey()) * 100) + "%",
                "§c실패하면 재료가 사라집니다"));
        res.setItemMeta(m);
        e.setResult(res);
        v.setRepairCost(plugin.getConfig().getInt("anvil-level-cost", 1));
    }

    @EventHandler
    public void onAnvilClick(InventoryClickEvent e) {
        if (!(e.getInventory() instanceof AnvilInventory ai)) return;
        if (e.getRawSlot() != 2) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String rn = (e.getView() instanceof AnvilView av) ? av.getRenameText() : null;
        Tool t = match(ai, rn);
        if (t == null) return;
        ItemStack res = ai.getItem(2);
        if (res == null || res.getType() != t.result()) return;

        e.setCancelled(true);
        int cost = plugin.getConfig().getInt("anvil-level-cost", 1);
        boolean creative = p.getGameMode() == GameMode.CREATIVE;
        if (!creative && p.getLevel() < cost) {
            p.sendMessage("§c경험치 레벨이 부족합니다. (필요: " + cost + ")");
            return;
        }
        if (!creative) p.setLevel(p.getLevel() - cost);

        consume(ai, 0, t.ingots());
        consume(ai, 1, t.sticks());
        ai.setItem(2, null);

        if (ThreadLocalRandom.current().nextDouble() < chance(t.tierKey())) {
            plugin.giveOrDrop(p, new ItemStack(t.result()));
            p.sendMessage("§a제작 성공!");
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 1f, 1.2f);
        } else {
            p.sendMessage("§c제작 실패... 재료가 사라졌습니다.");
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
        }
        Bukkit.getScheduler().runTask(plugin, p::updateInventory);
    }

    private void consume(Inventory inv, int slot, int n) {
        ItemStack s = inv.getItem(slot);
        if (s == null) return;
        if (s.getAmount() <= n) {
            inv.setItem(slot, null);
        } else {
            s.setAmount(s.getAmount() - n);
            inv.setItem(slot, s);
        }
    }

    // ───────────────────────── 네더라이트 업그레이드 ─────────────────────────

    private boolean isNetheriteTool(Material m) {
        String n = m.name();
        return n.startsWith("NETHERITE_") && (n.endsWith("_SWORD") || n.endsWith("_PICKAXE")
                || n.endsWith("_AXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE"));
    }

    @EventHandler
    public void onSmith(SmithItemEvent e) {
        SmithingInventory inv = e.getInventory();
        ItemStack res = inv.getResult();
        if (res == null || !isNetheriteTool(res.getType())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        e.setCancelled(true);
        ItemStack out = res.clone();
        for (int i = 0; i < 3; i++) consume(inv, i, 1); // 템플릿, 기존 도구, 네더라이트 주괴
        inv.setResult(null);

        if (ThreadLocalRandom.current().nextDouble() < chance("netherite")) {
            plugin.giveOrDrop(p, out);
            p.sendMessage("§a네더라이트 강화 성공!");
            p.playSound(p.getLocation(), Sound.BLOCK_SMITHING_TABLE_USE, 1f, 1.2f);
        } else {
            p.sendMessage("§c네더라이트 강화 실패... 도구가 파괴되었습니다.");
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 0.8f);
        }
        Bukkit.getScheduler().runTask(plugin, p::updateInventory);
    }
}
