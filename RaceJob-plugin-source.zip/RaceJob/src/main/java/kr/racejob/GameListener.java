package kr.racejob;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

public class GameListener implements Listener {

    private final RaceJobPlugin plugin;

    private static final Set<Material> COOKED_MEAT = EnumSet.of(
            Material.COOKED_BEEF, Material.COOKED_PORKCHOP, Material.COOKED_CHICKEN,
            Material.COOKED_MUTTON, Material.COOKED_RABBIT, Material.COOKED_COD, Material.COOKED_SALMON);

    public GameListener(RaceJobPlugin plugin) {
        this.plugin = plugin;
    }

    // ───────────────────────── 접속 / 종료 / 사망 ─────────────────────────

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.raceCache.remove(p.getUniqueId());
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        if (!pdc.has(plugin.kInit, PersistentDataType.BYTE)) {
            pdc.set(plugin.kInit, PersistentDataType.BYTE, (byte) 1);
            plugin.setFlag(p, plugin.kPendRace, true);
            plugin.setFlag(p, plugin.kPendJob, true);
            if (plugin.getConfig().getBoolean("give-starter-materials", true)) {
                plugin.giveOrDrop(p, new ItemStack(Material.PAPER, 2));
                plugin.giveOrDrop(p, new ItemStack(Material.NETHERITE_INGOT, 1));
                plugin.giveOrDrop(p, new ItemStack(Material.NETHER_STAR, 1));
            }
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            plugin.refresh(p);
            if (plugin.flag(p, plugin.kPendRace)) {
                p.sendMessage("§e종족을 선택해주세요! (/race)");
                plugin.openRaceMenu(p);
            } else if (plugin.flag(p, plugin.kPendJob)) {
                p.sendMessage("§e직업을 선택해주세요! (/job)");
                plugin.openJobMenu(p);
            }
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        plugin.raceCache.remove(id);
        plugin.stateCache.remove(id);
        plugin.disguised.remove(id);
        plugin.musicCount.remove(id);
        plugin.buffUntil.remove(id);
        plugin.buffReady.remove(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(i -> {
            String t = plugin.tagOf(i);
            return "race_elytra".equals(t) || "music_helmet".equals(t);
        });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        plugin.stateCache.remove(p.getUniqueId());
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            plugin.refresh(p);
            plugin.ensureItems(p);
        }, 2L);
    }

    // ───────────────────────── 메뉴 ─────────────────────────

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof RaceJobPlugin.MenuHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || !it.hasItemMeta()) return;
        String c = it.getItemMeta().getPersistentDataContainer().get(plugin.kChoice, PersistentDataType.STRING);
        if (c == null) return;

        if (h.race) {
            if (!plugin.flag(p, plugin.kPendRace)) { p.closeInventory(); return; }
            plugin.chooseRace(p, Race.valueOf(c));
            p.closeInventory();
            if (plugin.flag(p, plugin.kPendJob)) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (p.isOnline()) plugin.openJobMenu(p);
                }, 5L);
            }
        } else {
            if (!plugin.flag(p, plugin.kPendJob)) { p.closeInventory(); return; }
            plugin.chooseJob(p, Job.valueOf(c));
            p.closeInventory();
        }
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof RaceJobPlugin.MenuHolder) e.setCancelled(true);
    }

    // ───────────────────────── 우클릭 (선택권 / 전직의 별 / 음악가) ─────────────────────────

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        ItemStack it = e.getItem();
        String tag = plugin.tagOf(it);

        if (tag != null) {
            switch (tag) {
                case "star" -> { e.setCancelled(true); useStar(p); }
                case "ticket_race" -> {
                    e.setCancelled(true);
                    consumeHand(p);
                    plugin.setFlag(p, plugin.kPendRace, true);
                    plugin.openRaceMenu(p);
                }
                case "ticket_job" -> {
                    e.setCancelled(true);
                    consumeHand(p);
                    plugin.setFlag(p, plugin.kPendJob, true);
                    plugin.openJobMenu(p);
                }
                default -> { }
            }
            return;
        }

        if (plugin.getJob(p) == Job.MUSICIAN && plugin.extraUnlocked(p)) {
            boolean juke = (it != null && it.getType() == Material.JUKEBOX)
                    || (a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null
                    && e.getClickedBlock().getType() == Material.JUKEBOX);
            if (juke) plugin.musicianBuff(p);
        }
    }

    private void consumeHand(Player p) {
        ItemStack h = p.getInventory().getItemInMainHand();
        h.setAmount(h.getAmount() - 1);
    }

    private void useStar(Player p) {
        Job j = plugin.getJob(p);
        if (j == null) { p.sendMessage("§c직업이 없어서 사용할 수 없습니다."); return; }
        int t = plugin.getTier(p);
        if (t >= 3) { p.sendMessage("§e이미 최고 단계(T3)입니다."); return; }
        consumeHand(p);
        plugin.setTier(p, t + 1);
        plugin.musicCount.remove(p.getUniqueId());

        Firework fw = p.getWorld().spawn(p.getLocation().add(0, 1, 0), Firework.class);
        fw.getPersistentDataContainer().set(plugin.kTag, PersistentDataType.STRING, "fx");
        FireworkMeta fm = fw.getFireworkMeta();
        fm.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.STAR)
                .withColor(Color.YELLOW, Color.AQUA).withFade(Color.WHITE).flicker(true).build());
        fw.setFireworkMeta(fm);
        fw.detonate();

        Bukkit.broadcastMessage("§6[전직] §e" + p.getName() + "§f이(가) 전직 §bt" + (t + 1) + "§f에 성공했습니다!");
    }

    /** 전직 연출용 폭죽이 피해를 주지 않도록 */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onFireworkFx(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Firework f
                && "fx".equals(f.getPersistentDataContainer().get(plugin.kTag, PersistentDataType.STRING))) {
            e.setCancelled(true);
        }
    }

    // ───────────────────────── 전투 ─────────────────────────

    /** 받는 피해 보정 (종족) */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamaged(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        Race r = plugin.getRace(v);
        double m = 1.0;
        switch (r) {
            case BLIND, GIANT -> m = 0.5;
            case DWARF -> { if (e.getCause() == DamageCause.FALL) m = 2.0; }
            case VAMPIRE -> {
                switch (e.getCause()) {
                    case FIRE, FIRE_TICK, LAVA, HOT_FLOOR ->
                            m = plugin.getConfig().getDouble("vampire-fire-damage-multiplier", 2.0);
                    default -> { }
                }
            }
            default -> { }
        }
        if (m != 1.0) e.setDamage(e.getDamage() * m);
    }

    /** 주는 피해 보정 (종족 + 직업) 및 추가능력 */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        Player atk;
        boolean ranged = false;
        if (e.getDamager() instanceof Player pl) {
            atk = pl;
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sp) {
            atk = sp;
            ranged = true;
        } else {
            return;
        }
        if (plugin.echoing.contains(atk.getUniqueId())) return;
        if (!(e.getEntity() instanceof LivingEntity victim)) return;

        Race r = plugin.getRace(atk);
        Job j = plugin.getJob(atk);
        int tier = plugin.getTier(atk);
        boolean extra = plugin.extraUnlocked(atk);
        double mult = 1.0;

        switch (r) {
            case BLIND, GIANT -> mult *= 2.0;
            case DWARF -> mult *= 0.5;
            default -> { }
        }

        if (r == Race.VAMPIRE && !ranged && victim instanceof Player) {
            AttributeInstance mh = atk.getAttribute(Attribute.MAX_HEALTH);
            atk.setHealth(Math.min(mh.getValue(), atk.getHealth() + 1.0));
        }

        Material hand = atk.getInventory().getItemInMainHand().getType();
        boolean swordHit = false, brawlHit = false;
        if (j != null) {
            switch (j) {
                case SWORDSMAN -> {
                    if (!ranged && hand.name().endsWith("_SWORD")) {
                        mult *= 1 + RaceJobPlugin.SWORD_BONUS[tier];
                        swordHit = true;
                    }
                }
                case ARCHER -> {
                    if (ranged && e.getDamager() instanceof AbstractArrow && !(e.getDamager() instanceof Trident)) {
                        mult *= 1 + RaceJobPlugin.BOW_BONUS[tier];
                    }
                }
                case BRAWLER -> {
                    if (!ranged && hand == Material.AIR) {
                        mult *= 1 + RaceJobPlugin.BRAWL_BONUS[tier];
                        brawlHit = true;
                    }
                }
                case MUSICIAN -> {
                    Long until = plugin.buffUntil.get(atk.getUniqueId());
                    if (until != null && until > System.currentTimeMillis()) mult *= 1.2;
                }
            }
        }

        double dmg = e.getDamage() * mult;
        e.setDamage(dmg);

        if (extra) {
            if (swordHit) plugin.echo(atk, victim, dmg, 20L);          // 1초 뒤 한 번 더
            if (brawlHit) plugin.echo(atk, victim, dmg, 30L, 60L);     // 3초에 걸쳐 2회
        }
    }

    /** 궁수 추가능력: 화살 3발 */
    @EventHandler(ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (plugin.getJob(p) != Job.ARCHER || !plugin.extraUnlocked(p)) return;
        if (!(e.getProjectile() instanceof AbstractArrow orig)) return;
        Vector v = orig.getVelocity();
        for (double ang : new double[]{-10, 10}) {
            Arrow a = p.getWorld().spawn(orig.getLocation(), Arrow.class);
            a.setShooter(p);
            a.setVelocity(v.clone().rotateAroundY(Math.toRadians(ang)));
            a.setCritical(orig.isCritical());
            a.setDamage(orig.getDamage());
            a.setFireTicks(orig.getFireTicks());
            a.setPickupStatus(AbstractArrow.PickupStatus.CREATIVE_ONLY);
        }
    }

    // ───────────────────────── 종족 단점 ─────────────────────────

    @EventHandler(ignoreCancelled = true)
    public void onEat(PlayerItemConsumeEvent e) {
        Player p = e.getPlayer();
        if (plugin.getRace(p) == Race.VAMPIRE && COOKED_MEAT.contains(e.getItem().getType())) {
            e.setCancelled(true);
            p.sendMessage("§c흡혈귀는 익힌 고기를 먹을 수 없습니다.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEffect(EntityPotionEffectEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (e.getNewEffect() == null) return;
        if (e.getNewEffect().getType().equals(PotionEffectType.FIRE_RESISTANCE)
                && plugin.getRace(p) == Race.VAMPIRE) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Race r = plugin.raceCache.get(e.getPlayer().getUniqueId());
        if (r == Race.FURRY) e.message(e.message().append(Component.text(" meow")));
    }
}
