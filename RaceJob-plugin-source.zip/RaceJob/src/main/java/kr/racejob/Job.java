package kr.racejob;

import org.bukkit.Material;

public enum Job {
    SWORDSMAN("검사", Material.STONE_SWORD,
            "돌검 지급, 검 데미지 +20%",
            "전직: T1 25% / T2 30% / T3 40%",
            "추가능력: 타격 1초 뒤 같은 데미지 한 번 더"),
    ARCHER("궁수", Material.BOW,
            "활 지급, 활 데미지 +20%",
            "전직: T1 25% / T2 30% / T3 40%",
            "추가능력: 화살이 한 번에 3발"),
    BRAWLER("길거리 싸움꾼", Material.IRON_NUGGET,
            "주먹 데미지 +20%",
            "전직: T1 40% / T2 60% / T3 100%",
            "추가능력: 타격 시 3초에 걸쳐 넉백+데미지 2회 추가"),
    MUSICIAN("음악가", Material.JUKEBOX,
            "머리에 주크박스, 5초마다 반경 3칸 파동(갑옷 무시 0.5하트)",
            "전직: 주기 T1 3초 / T2 2초 / T3 1초",
            "추가능력: 주크박스 우클릭 시 5초간 공격 +20%");

    public final String display;
    public final Material icon;
    public final String[] lore;

    Job(String display, Material icon, String... lore) {
        this.display = display;
        this.icon = icon;
        this.lore = lore;
    }
}
